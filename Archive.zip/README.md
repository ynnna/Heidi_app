# ReadME

Shinny app for simulating predictions derived form the model HeiDI.

## Contact details
+ email: iliescuaf@cardiff.ac.uk
+ Institutional profile: [Dr Adela Iliescu](https://www.cardiff.ac.uk/people/view/2420714-).

## Software
The software needed to reproduce these simulation is R and RStudio.

First download and install the latest R version for your operating system [here](https://www.r-project.org). Then install RStudio Desktop following the instructions provided [here](https://rstudio.com/products/rstudio/).
To install the necessary packages run ``install_packages.R`` (file used to check and install necessary packages).
